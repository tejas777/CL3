import os
import random
import hashlib

def isprime(num):
	if num<2:
		return False
	elif num==2:
		return True
	else:
		for x in range(2,num):
			if num % x == 0:
				return False
		return True

def check_tuple_compat(p,q):
	if not isprime(p):
		print "p is not Prime"
		return False
	if not isprime(q):
		print "q is not Prime"
		return False
	if (p-1)%q !=0:
		print "p is not prime modulas of q"
		return False
	return True

def get_g(p,q,h):
	for g in range(1,p):
		if pow(g,q)%p!=1 or g!=pow(h,((p-1)/q))%p:
			g = g+1
		else:
			return g
	return -1

while True:
	print "Enter the parameter tuple<p,q> :"
	p = input('p: ')
	q = input('q: ')
	
	if not check_tuple_compat(p,q):
		print "Invalid parameter tuple... try again!!!"
	else:
		break

msg = raw_input("Enter the message : ")
m = hashlib.sha1()
m.update(msg) # to feed the msg as arbritary string
print m.hexdigest() # for concatination of multiple string
h = int(str(m.hexdigest()),16) #16 bytes
print "h : ",h
g = get_g(p,q,h)
print "g : ",g

while True:
	x = input("Enter the value of x (1<x<q) : ")
	if x<1 and x>q:
		print "Invalid x... try again!!!"
	else:
		break

y = pow(g,x)%q
print "public key : ",[p,q,g,y]
print "private key : ",[p,q,g,x]

k = random.randint(1,q)
r = (pow(g,k)%p)%q
i = 0
while True:
	if (k*i)%q==1:
		break
	i = i+1
s = i*(h+r*x)
print "Digital signature produced {r,s} : ",[r,s]

w = 0
while True:
	if (s*w)%q==1:
		break
	w = w+1
u1 = (h*w)%q
u2 = (r*w)%q
v = ((pow(g,u1)*pow(g,u2))%p%q)

if v==r:
	print "Verification Successful"
else:
	print "Verification Failed"

