import java.security.MessageDigest;
import java.util.*;
import java.util.Scanner;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class App {

	public static void main(String[] args) {

		System.out.println("Enter message to be sent:");
		Scanner Input = new Scanner(System.in);
		String str = Input.nextLine();

		System.out.println("Enter your key: ");
		int PK = Input.nextInt();
        RandomNumber R1 = new RandomNumber(PK);
        RandomNumber R2 = new RandomNumber(PK);

        try
        {
		//You should use SHA-1 to generate a hash from your key and trim the result to 128 bit (16 bytes).
		//The getBytes("UTF-8") then encodes the characters as a sequence of bytes, and returns them in a newly allocated byte array.
	        byte[] key = Integer.toString(R1.generate()).getBytes("UTF-8");
		//Message digests are secure one-way hash functions that take arbitrary-sized data and output a fixed-length hash value. 
	        MessageDigest SHA = MessageDigest.getInstance("SHA-1");
		//one of the digest methods should be called to complete the hash computation. 
	        key = SHA.digest(key);
	        key = Arrays.copyOf(key, 16); //aes input size=16 bytes
	        SecretKeySpec SK = new SecretKeySpec(key,"AES");
	        // build the initialisation vector.  This example is all zeros, but it
	        // could be any value or generated using a random number generator.
	        byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		//IV is needed for block cipher mode encryption(AES)
	        IvParameterSpec IVspec = new IvParameterSpec(iv); //iv is needed for block cypher mode encryption

	        Cipher Encrypt;
	        Encrypt = Cipher.getInstance("AES/CBC/PKCS5Padding"); //CBC=cipher block chaining
		//PKCS5Padding cannot be used with AES since it is defined only for a block size of 8 bytes.assume, AES/CBC/PKCS5Padding 			//is interpreted as AES/CBC/PKCS7Padding internally.The only difference between these padding schemes is that PKCS7Padding 			//has the block size as a parameter, while for PKCS5Padding it is fixed at 8 bytes. When the Block size is 8 bytes they do 			//exactly the same.
	        Encrypt.init(Cipher.ENCRYPT_MODE, SK, IVspec);       // initialize the cipher with the key and IV
	        byte[] encrypted = Encrypt.doFinal(str.getBytes()); //finally encrypt (do XOR with the previous IV)
	        System.out.println("Encrypted string : "+ Arrays.toString(encrypted));


	        byte[] key1 = Integer.toString(R2.generate()).getBytes("UTF-8");
	        MessageDigest SHA1 = MessageDigest.getInstance("SHA-1");
	        key1 = SHA1.digest(key1);
	        key1 = Arrays.copyOf(key1, 16);
	        SecretKeySpec SK1 = new SecretKeySpec(key1,"AES");

	        Cipher Decrypt;
	        Decrypt = Cipher.getInstance("AES/CBC/PKCS5Padding");
		//CBC provides message dependence for generating ciphertext and makes the system non-deterministic.
	        Decrypt.init(Cipher.DECRYPT_MODE, SK1, IVspec); //Construct a new AES key schedule 
	        byte[] decrypted = Decrypt.doFinal(encrypted);
	        System.out.println("Decrypted string : "+ new String(decrypted, "UTF-8"));

        }
        catch(Exception e)
        {
        	e.printStackTrace();
		//printStackTrace() helps the programmer to understand where the actual problem occurred. 
		//printStacktrace() is a method of the class Throwable of java.lang package.
        	Input.close();
		//Scanner opens an underlying OS's file descriptor (or file channel, or stream), which typically is written in a 			//non-managed(typically C language).A stream kept open, can sometimes stay opened until the kernel decides to close it(like, 			//after the program has completed execution... highly implementation dependent). 
        }
        Input.close();
	}
}
