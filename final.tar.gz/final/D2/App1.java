import java.util.*;
import.java.io.*;
import.java.security.MessageDigest;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class App{
	}
