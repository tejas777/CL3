public class RandomNumber1{
	long previousNumber;
	int NumberLength = 4;
	public RandomNumber(){
		previousNumber = System.currentTimeMillis()%Integer.MAX_VALUE;
	}
	
	public RandomNumber(int seed){
			previousNumber = seed;
			String number = Long.toString(previousNumber);
			NumberLength = number.length();
		}
	
	public int generate(){
		previousNumber++;
		previousNumber = previousNumber * previousNumber;
		String number = Long.toString(PreviousNumber);
		int a = (number.length()/2) - (NumberLength/2);
		StringBuilder NewNumber = new StringBuilder();
		for(int i = a;i< a+NumberLength & i>=0 ;i++){
			NewNumber.append(number.charAt(i));
		}
		previousNumber = Long.parseLong(NewNumber.toString());
		return (int)previousNumber;
		}
	
	
	}
