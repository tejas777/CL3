public class SecurePassword {
public String Password;
SecurePassword(String str)
{
Password = str;
}
}