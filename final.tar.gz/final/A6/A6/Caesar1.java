import java.util.*;

public class Caesar1 {

	public static char p[] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
			'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
			'w', 'x', 'y', 'z'
	};
	
	public static char ch[] = { 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O',
			'P', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Z', 'X', 'C',
			'V', 'B', 'N', 'M'
	};
	
	public static String doEncryption(String str, int s){
		if(s<0){
			return "Invalid Input";
		}
		
		String str1 = str.toLowerCase();
		String str2 = "";
		
		for(int i=0;i<str.length();i++){
			str2 = str2 + (char)(((((str.charAt(i) - 97) -3) +26) %26) + 97);  
		}
		return str2;
	}
	
	public static String doEncryption(String s){
		String str1 = "";
		for(int i = 0;i<s.length();i++){
			for(int j = 0;j<26;j++){
				if(s.charAt(i) == p[j]){
					str1 = str1 + ch[j];
				}
			}
		}
		return str1;
	}
	
	
	
	public static void main(String args[]){
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Password : ");
		String pass = scan.next();
		while(true){
		System.out.println("Enter Choice\n1.Caesar cipher\n2.Monoalphabetic Cipher\n3.Exit");
		
		int choice = scan.nextInt();
		
		switch(choice){
			case 1:
				System.out.println("Caesar Cipher : " + doEncryption(pass, 3));
			break;
			
			case 2:
				System.out.println("Monoalphabatic Cipher : " + doEncryption(pass));
			break;
			
			case 3:
				System.exit(0);
		}
		}
		
	}
}
