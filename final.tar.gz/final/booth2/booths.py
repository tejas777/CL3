import os

def decimal_to_binary(num):
	i = 7
	arr = [0]*8
	while num and (i>=0):
		arr[i] = num%2
		num = num/2
		i = i-1
	return arr
	
def add(num1,num2):
	arr = [0]*17
	c = 0
	i = 16
	while(i>=0):
		temp = num1[i] + num2[i] + c
		arr[i] = temp%2
		c = temp/2
		i = i-1
	return arr
	
def right_shift(x):
	i = 16
	while(i>=1):
		x[i] = x[i-1]
		i = i-1
	return x
	
def binary_to_decimal(p):
	neg = 0
	if (p[0]==1):
		neg = 1
		i = 15
		while(i>=1):
			if(p[i]==0):
				i = i-1
			else:
				break
		for x in range (0,i):
			p[x] = 1 - p[x]
	
	ans = 0
	temp = 0
	i = 15
	while(i>=0):
		if(p[i]==1):
			ans = ans + 2**temp
		temp = temp + 1
		i = i - 1
		
	if neg:
		return -ans
	else:
		return ans

def mult(num1,num2):
	M = decimal_to_binary(num1)
	Q = decimal_to_binary(num2)
	minus_M = decimal_to_binary(-num1)
	
	p=[0]*8
	p.extend(Q)
	p.append(0)
	
	M += [0]*9
	minus_M += [0]*9
	
	print "M       : ",M
	print "minus_M : ",minus_M
	print "Q Q-1   : ",p
	print "\n"
	
	for i in range(8):
		if (p[-2]==0) and (p[-1]==1):
			p = add(p,M)
			print "A = A + M ======= : ",p
		if (p[-2]==1) and (p[-1]==0):
			p = add(p,minus_M)
			print "A = A - M ======= : ",p
		p = right_shift(p)
		print "Right Shift =======   : ",p
		
	p = p[:-1]
	print "Final Answer =======      : ",p
	
	answer = binary_to_decimal(p)
	print answer
	return (answer, decimal_to_binary(answer))
	
a,b = mult(-2,3)
print a,b

