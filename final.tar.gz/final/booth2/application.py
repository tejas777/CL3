from flask import *
from booths import *

app = Flask(__name__)

@app.route('/')
def home():
	return render_template('index.html')
	
@app.route('/multiplication', methods =["POST"])
def multiply():
	return render_template('index.html', prod = mult(int(request.form["num1"]),int(request.form["num2"])))
	
if __name__ == '__main__':
	app.run() 
