import os
import xml.etree.ElementTree as ET
import unittest
import threading

def takeInput(filename):
	with open(filename) as f:
		tree = ET.parse(filename)
		root = tree.getroot()
		arr = root.text.split()
		arr1 = []
		for x in arr:
			arr1.append(int(x))
		print arr1
		return arr1

def quicksort(arr,low,high):
	if (low < high):
		pi = partition(arr,low,high)
		t1 = threading.Thread(quicksort(arr,low,pi-1))
		t2 = threading.Thread(quicksort(arr,pi+1,high))
		print t1.getName(), "is running for ", str(arr)
		t1.start()
		print t2.getName(), "is running for ", str(arr)
		t2.start()
		t1.join()
		t2.join()

def quicksort(arr,low,high):
	if(low < high):
		pi = partition(arr,low,high)
		t1 = threading.Thread(quicksort(arr,low,pi-1))
		t2 = threading.Thread(quicksort(arr,pi+1,high))
		print t1.getName(), "is running for ", str(arr)
		t1.start()
		print t2.getName(), "is running for", str(arr)
		t2.start()
		t1.join()
		t2.join()

def partition(arr,low,high):
	pivot = arr[high]
	pIndex = low - 1
	for j in range(low, high):
		if (arr[j] <= pivot):
			pIndex = pIndex + 1
			arr[pIndex],arr[j] = arr[j],arr[pIndex]
	arr[pIndex+1],arr[high] = arr[high],arr[pIndex+1]
	print "changed out", arr
	print "pIndex", pIndex+1
	print pivot
	return (pIndex + 1)

class Test(unittest.TestCase):
	def test_postive(self):
		self.assertEquals(takeInput("input.xml"),[17, 31, 3, 66, 1, 69, 25, 15, 93, 64])
	def test_postive1(self):
		self.assertEquals(takeInput("input1.xml"),[18, 31, 3, 66, 1, 69, 25, 15, 93, 64])
	def test_negative(self):
		self.assertRaises(IOError,takeInput,"input.txt")

arr = takeInput("input.xml")
quicksort(arr,0,len(arr)-1)
print "Sorted Array : "+ str(arr)
print "Testing Results...\n"
unittest.main()
