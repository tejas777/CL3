import os 
import xml.etree.ElementTree as ET
import unittest
import threading
def takeInput(filename):
	with open(filename) as f:
		tree = ET.parse(filename)
		root= tree.getroot()
		arr=root.text.split()
		arr=[int(x) for x in arr]
		print arr	
		return arr

def partition(arr,low,high):
    pIndex = ( low-1 )         # index of smaller element
    pivot = arr[high]     # pivot
    for j in range(low , high):
        if   arr[j] <= pivot:
            pIndex = pIndex+1
            #print arr
            arr[pIndex],arr[j] = arr[j],arr[pIndex]
            #print "changed",arr
    #print arr
    arr[pIndex+1],arr[high] = arr[high],arr[pIndex+1]
    print "changed out",arr
    print "pIndex",pIndex+1
    print pivot
    return ( pIndex+1 )
 
def quickSort(arr,low,high):
	if low < high:
		pi = partition(arr,low,high)
		t1=threading.Thread(quickSort(arr, low, pi-1))
		t2=threading.Thread(quickSort(arr, pi+1, high))
		print t1.getName(),"is running for ",str(arr)
		#print t1.getName(),"is running for partition from ",start,"to ",mid 
		t1.start()
		print t2.getName(),"is running for ",str(arr)
		#print t2.getName(),"is running for partition from ",mid+1,"to ",last
		t2.start()
		t1.join()
		t2.join()
'''
def QuickSort(arr,start,last):
	if(start<last):
		mid=Partition(arr,start,last)
		t1=threading.Thread(QuickSort(arr,start,mid-1))
		t2=threading.Thread(QuickSort(arr,mid+1,last))	
		print t1.getName(),"is running for ",str(arr)
		#print t1.getName(),"is running for partition from ",start,"to ",mid 
		t1.start()
		print t2.getName(),"is running for ",str(arr)
		#print t2.getName(),"is running for partition from ",mid+1,"to ",last
		t2.start()
		t1.join()
		t2.join()
'''	

class Test(unittest.TestCase):
	def test_postive(self):
		self.assertEquals(takeInput("input.xml"),[17, 31, 3, 66, 1, 69, 25, 15, 93, 64])
	def test_postive1(self):
		self.assertEquals(takeInput("input1.xml"),[18, 31, 3, 66, 1, 69, 25, 15, 93, 64])
	def test_negative(self):
		self.assertRaises(IOError,takeInput,"input.txt")
	

input_file='input.xml'
arr=takeInput(input_file)
quickSort(arr,0,len(arr)-1)
print "Sorted Array:"+ str(arr)
#print arr
print "Tesing Results...\n"
unittest.main()
