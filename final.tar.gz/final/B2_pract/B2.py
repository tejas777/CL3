import os
from flask import Flask
from flask import render_template
from flask import request

app = Flask(__name__)

class PlagiarismChecker:
	def __init__(self,filename):
		self.filename=filename
		self.linescore=0
		self.wordscore=0
		self.data_lines=[]
		self.data_words=set()
		self.input_lines=[]
		self.input_words=set()
		
	def loadData(self):
		temp = []
		with open(self.filename) as f:
			for lines in f:
				for line in lines.split("."):
					line = line.replace(",","")
					line = line.replace(".\n","")
					line = line.replace("\n","")
					line = line.replace(":","")
					line = line.replace("'","")
					line = line.lower()
					self.data_lines.append(line)
					temp = line.split()
					for val in temp:
						self.data_words.add(val)
	
	def loadInput(self,inp_string):
		temp = []
		for line in inp_string.split('.'):
			line = line.replace(",","")
			line = line.replace(".\n","")
			line = line.replace("\n","")
			line = line.replace(":","")
			line = line.replace("'","")
			line = line.lower()
			self.input_lines.append(line)
			temp = line.split()
			for val in temp:
				self.input_words.add(val)
	
	def scoreByWords(self):
		for dword in self.data_words:
			for iword in self.input_words:
				if(dword == iword):
					self.wordscore+=1
		print self.wordscore
		self.wordscore = float(self.wordscore)/float(len(self.data_words))*100
		
	def scoreByLines(self):
		for dline in self.data_lines:
			for iline in self.input_lines:
				if(dline == iline and ((dline or iline) != '')):
					self.linescore += 1
		print self.linescore
		self.linescore = float(self.linescore)/float(len(self.data_lines))*100
	
	def checkPlagiarism(self):
		self.scoreByWords()
		self.scoreByLines()
		print "Score by word matching = ",self.wordscore
		print "Score by line matching = ",self.linescore
		print "Average Score = ",float((self.wordscore+self.linescore)/2)
		return "Score := "+str(float((self.wordscore+self.linescore)/2))
		
@app.route('/')
def init():
	return render_template("index.html")
	
@app.route('/',methods=["POST"])
def calculate():
	obj = PlagiarismChecker('data.txt')
	obj.loadData()
	str_inp = request.form["val"]
	obj.loadInput(str_inp)
	someVal = obj.checkPlagiarism()
	return someVal
	
if __name__ == "__main__":
	app.run("localhost",debug = True)	
