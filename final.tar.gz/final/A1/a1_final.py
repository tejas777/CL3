import os
import unittest

def read(filename):
	a = open(filename,'r')
	ind = []
	for i in a:
		ind.append(int(i))
	return (ind)
	
