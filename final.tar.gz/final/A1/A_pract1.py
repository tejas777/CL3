import os
import unittest

def read(filename):
	a = open(filename, 'r')
	inx = []
	for ind in a:
		inx.append(int(ind))
	return inx

def sort(srt):
	srt.sort()
	return srt

def search(key,arr,first,last):
	if(first<=last):
		mid = (first+last)/2
		if(key == arr[mid]):
			return mid
		elif(key < arr[mid]):
			return search(key,arr,first,mid-1)
		elif(key > arr[mid]):
			return search(key,arr,mid+1,last)

class Test(unittest.TestCase):
	def test_positive(self):
		self.assertEqual(search(1,[0,1,2,3,4,5],0,5),1)
	def test_negative(self):
		self.assertEqual(search(10,[0,1,2,3,4,5],0,5),None)

some = read("input.txt")
print "The elements in the array is :", some
srt = sort(some)
print "The sorted array is : ", srt
key = input("Enter the number to be searched : ")
index = search(key,srt,0,len(srt)-1)
print "The element found at the index : ", index
print "Unit Testing : "
unittest.main()
