from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver = webdriver.Firefox()
driver.get("http://localhost:5000")
elem = driver.find_element_by_name("val")
elem.send_keys("Abstract art is a visual form of colors")
elem.send_keys(Keys.RETURN)
#assert "100.00" in driver.page_source
#driver.close()

