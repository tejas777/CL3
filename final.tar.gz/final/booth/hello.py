import os

def decimal_to_binary(x):
	arr = [0]*8
	i=7
	while x and (i>=0):
		arr[i] = x%2
		x = x/2
		print arr[i]
		print x
		i -= 1
	return arr

a = decimal_to_binary(-2)
print a


print (-1/2)
