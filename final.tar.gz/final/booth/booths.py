#booth's multiplication algorithm

def decimal_to_binary(x):
	arr = [0]*8
	i=7
	while x and (i>=0):
		arr[i] = x%2
		x = x/2  
		i -= 1
	return arr

def add(x,y):
	z = [0]*17
	c = 0
	i =16
	while(i>=0):
		temp = x[i] + y[i] +c
		z[i] = temp%2
		c = temp/2
		i=i-1
	return z

def right_shift(x):
	i=16
	while(i>=1):
		x[i] = x[i-1]
		i =i-1
	return x

def binary_to_decimal(p):
	neg = 0
	if p[0] == 1:
		neg = 1
		x = 15
		while(x>=1):			#taking 2's compliment of the final negative answer
			if(p[x]==0):
				x=x-1
			else:
				break
		for i in range (0,x):	#inverting the values 
			p[i] = 1 - p[i]

	ans = 0
	temp = 0
	i= 15
	while(i>=0):
		if (p[i]==1):
			ans += 2**temp
		temp = temp + 1
		i = i-1

	if neg:
		return -ans
	return ans

def mult(num1, num2):
	M = decimal_to_binary(num1)
	Q = decimal_to_binary(num2)
	minus_M = decimal_to_binary(-num1)

	p=[0]*8
	p.extend(Q)
	p.append(0)

	M += [0]*9
	minus_M += [0]*9

	print "M       :",M
	print "minus_M :",minus_M
	print "Q Q-1   :",p
	print "\n"

	for i in range (8):
		#print "------Step "+str(i+1)+" ------"
		if (p[-2]==0) and (p[-1]==1):
			p = add(p,M)
			print "A = A + M ============ : ",p
		if (p[-2]==1) and (p[-1]==0):
			p = add(p,minus_M)
			print "A = A - M ============ : ",p
		p = right_shift(p)
		print "Right Shift=========== : ",p

	p = p[:-1]
	print "Fianl Answer========== : ",p

	answer = binary_to_decimal(p)
	print answer
	return (answer,decimal_to_binary(answer))
'''
print "Enter two numbers"
num1 = int(raw_input())
num2 = int(raw_input())

answer = mult(num1, num2)
'''
a,b = mult(-2,3)
print a,b
